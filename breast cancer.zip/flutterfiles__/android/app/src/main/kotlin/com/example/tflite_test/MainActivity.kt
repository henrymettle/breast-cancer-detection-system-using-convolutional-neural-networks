package com.example.tflite_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
