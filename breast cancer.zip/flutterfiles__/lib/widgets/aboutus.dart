import 'package:flutter/material.dart';

class ABOUT extends MaterialPageRoute<Null> {
  ABOUT()
      : super(builder: (BuildContext context) {
          return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.pink,
              foregroundColor: Colors.white,
              title: Text('About Us'),
              elevation: 5.0,
              centerTitle: true,
            ),
            body: SingleChildScrollView(
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 12,
                    ),
                    Card(
                      elevation: 20,
                      clipBehavior: Clip.hardEdge,
                      child: SizedBox(
                        width: 300,
                        // height: 580,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                               SizedBox(
                                height: 18,
                              ),
                              Container(
                                height: 135,
                                width: 135,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  image: const DecorationImage(
                                      image: AssetImage('assets/logo.jpg'),
                                      fit: BoxFit.fill),
                                ),
                              ),
                              SizedBox(
                                height: 12,
                              ),
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Column(
                                  children: [
                                    Text(
                                      "Breast Cancer Detection App ",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 12,
                                    ),
                                    Text(
                                      "Welcome to our Breast Cancer Detection App.  Our mission is to help medical practitioners in the early detection and prevention of breast cancer, one of the most prevalent types of cancer worldwide. We have developed an Android application that leverages the power of artificial intelligence and image analysis to provide users with a reliable and convenient tool for assessing their breast health. ",
                                      style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 16,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 12,
                                    ),
                                    Text(
                                      "At our core, we prioritize your well-being and aim to raise awareness about skin cancer risks. Our app allows users to capture images of their skin lesions and receive instant feedback regarding their potential malignancy. With our advanced algorithms and machine learning techniques, we strive to deliver accurate results that aid in the early detection of breast cancer. ",
                                      style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 16,
                                      ),
                                    ),

                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    // ElevatedButton(
                    //   onPressed: () {
                    //     // getImageCamera();
                    //   },
                    //   style: ElevatedButton.styleFrom(
                    //     padding: const EdgeInsets.symmetric(
                    //         horizontal: 30.0, vertical: 10.0),
                    //     shape: RoundedRectangleBorder(
                    //         borderRadius: BorderRadius.circular(13.0)),
                    //     foregroundColor: Colors.white,
                    //   ),
                    //   child: const Text(
                    //     "Take a photo",
                    //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    //   ),
                    // ),
                    // SizedBox(
                    //   height: 8,
                    // ),
                    // ElevatedButton(
                    //   onPressed: () {
                    //     // getImageGallery();
                    //   },
                    //   style: ElevatedButton.styleFrom(
                    //     padding: const EdgeInsets.symmetric(
                    //         horizontal: 30.0, vertical: 10.0),
                    //     shape: RoundedRectangleBorder(
                    //         borderRadius: BorderRadius.circular(13.0)),
                    //     foregroundColor: Colors.white,
                    //   ),
                    //   child: const Text(
                    //     "pick from gallery",
                    //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    //   ),
                    // ),
                    // SizedBox(
                    //   height: 8,
                    // ),
                  ],
                ),
              ),
            ),
          );
        });
}
